﻿
namespace CentricExpress.DevOps.Logging
{
    public interface ILog
    {
        void Run(string filePath, string env);
    }
}
